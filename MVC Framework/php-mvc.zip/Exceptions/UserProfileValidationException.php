<?php

namespace Exceptions;

class UserProfileValidationException extends ValidationException
{

}