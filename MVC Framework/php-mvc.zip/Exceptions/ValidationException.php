<?php
/**
 * Created by PhpStorm.
 * User: darcoto
 * Date: 11/16/17
 * Time: 17:14
 */

namespace Exceptions;


class ValidationException extends \Exception
{

}